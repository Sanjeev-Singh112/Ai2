"use client"

import Link from "next/link"
import {
  ChevronDown,
  Upload,
  Brain,
  Target,
  MessageCircle,
  BookOpen,
  Library,
  TrendingUp,
  User,
  Mail,
  FileText,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useEffect, useState } from "react"

export default function Home() {
  const [currentSection, setCurrentSection] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll(".scroll-section")
      const scrollPosition = window.scrollY + window.innerHeight / 2

      sections.forEach((section, index) => {
        const element = section as HTMLElement
        const offsetTop = element.offsetTop
        const offsetBottom = offsetTop + element.offsetHeight

        if (scrollPosition >= offsetTop && scrollPosition < offsetBottom) {
          setCurrentSection(index)
        }
      })
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (index: number) => {
    const section = document.getElementById(`section-${index}`)
    section?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="min-h-screen">
      {/* Fixed Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#E8D5B7]/90 backdrop-blur-sm">
        <div className="flex justify-between items-center px-8 py-6">
          <div className="flex space-x-8">
            <Link
              href="#"
              className="text-white text-sm font-light tracking-wider transition-all duration-300 hover:opacity-80 hover:translate-y-[-2px] relative group"
            >
              <span className="absolute left-0 bottom-0 w-0 h-[1px] bg-white opacity-0 transition-all duration-300 group-hover:w-full group-hover:opacity-70"></span>
              EXPERIMENT
            </Link>
            <Link
              href="#"
              className="text-white text-sm font-light tracking-wider transition-all duration-300 hover:opacity-80 hover:translate-y-[-2px] relative group"
            >
              <span className="absolute left-0 bottom-0 w-0 h-[1px] bg-white opacity-0 transition-all duration-300 group-hover:w-full group-hover:opacity-70"></span>
              KNOW MORE
            </Link>
            <Link
              href="#"
              className="text-white text-sm font-light tracking-wider transition-all duration-300 hover:opacity-80 hover:translate-y-[-2px] relative group"
            >
              <span className="absolute left-0 bottom-0 w-0 h-[1px] bg-white opacity-0 transition-all duration-300 group-hover:w-full group-hover:opacity-70"></span>
              SHOP
            </Link>
          </div>
          <div className="w-4 h-4 bg-white rounded-full opacity-60 transition-all duration-300 hover:opacity-100 hover:scale-110 cursor-pointer"></div>
        </div>
      </nav>

      {/* Section Indicators */}
      <div className="fixed right-8 top-1/2 transform -translate-y-1/2 z-50 space-y-2">
        {Array.from({ length: 10 }).map((_, index) => (
          <button
            key={index}
            onClick={() => scrollToSection(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              currentSection === index ? "bg-[#E85A7A] scale-125" : "bg-white/50 hover:bg-white/80"
            }`}
          />
        ))}
      </div>

      {/* Hero Section */}
      <section
        id="section-0"
        className="scroll-section min-h-screen bg-[#E8D5B7] flex items-center justify-center relative"
      >
        <div className="text-center">
          <div className="relative transition-all duration-500 hover:scale-105 cursor-pointer">
            <h1 className="text-8xl md:text-9xl font-bold text-[#E85A7A] font-script relative">
              Cyclemon
              <div className="absolute -top-4 -right-8 w-16 h-16 opacity-60">
                <div className="w-full h-full rounded-full border-2 border-[#F4A261] relative">
                  <div className="absolute inset-2 rounded-full border border-[#F4A261]"></div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-[#F4A261] text-xs font-bold">
                    C
                  </div>
                </div>
              </div>
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-20 h-8">
                <div className="w-full h-full bg-[#F4A261] opacity-60 rounded-full relative">
                  <div className="absolute inset-1 bg-[#E85A7A] rounded-full"></div>
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                </div>
              </div>
            </h1>
          </div>
          <p className="text-white/80 text-xl mt-8 max-w-2xl mx-auto">Your Ultimate AI-Powered Learning Companion</p>
        </div>
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <ChevronDown
            className="w-6 h-6 text-white opacity-60 transition-all duration-300 hover:opacity-100 hover:translate-y-1 cursor-pointer animate-bounce-subtle"
            onClick={() => scrollToSection(1)}
          />
        </div>
      </section>

      {/* 1. Notes Uploader */}
      <section
        id="section-1"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#F4A261] to-[#E76F51] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <Upload className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">Notes Uploader</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Upload your handwritten or digital notes and let our AI organize and digitize them for easy access and
            sharing.
          </p>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-8">
              <div className="border-2 border-dashed border-white/50 rounded-lg p-12 text-center">
                <Upload className="w-12 h-12 text-white/70 mx-auto mb-4" />
                <p className="text-white/80 text-lg">Drag and drop your notes here or click to browse</p>
                <Button className="mt-4 bg-white text-[#E76F51] hover:bg-white/90">Choose Files</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* 2. AI Summarizer */}
      <section
        id="section-2"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#2A9D8F] to-[#264653] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <Brain className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">AI Summarizer</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Transform lengthy documents and lectures into concise, digestible summaries powered by advanced AI.
          </p>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-8">
              <Textarea
                placeholder="Paste your text here to get an AI-powered summary..."
                className="min-h-32 bg-white/10 border-white/30 text-white placeholder:text-white/60"
              />
              <Button className="mt-4 bg-white text-[#2A9D8F] hover:bg-white/90">Generate Summary</Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* 3. Goal Setter */}
      <section
        id="section-3"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#E85A7A] to-[#C44569] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <Target className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">Goal Setter</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Set, track, and achieve your academic goals with personalized milestones and progress tracking.
          </p>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Academic Goals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-white">
                    <span>Complete Math Course</span>
                    <span className="text-sm bg-white/20 px-2 py-1 rounded">75%</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-white h-2 rounded-full w-3/4"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Weekly Targets</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-white">
                    <span>Study Hours</span>
                    <span className="text-sm bg-white/20 px-2 py-1 rounded">32/40</span>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div className="bg-white h-2 rounded-full w-4/5"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* 4. AI Companion */}
      <section
        id="section-4"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#6C5CE7] to-[#5A4FCF] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <MessageCircle className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">AI Companion</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Your personal AI tutor available 24/7 to answer questions, explain concepts, and provide learning support.
          </p>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-8">
              <div className="space-y-4 mb-6 max-h-64 overflow-y-auto">
                <div className="flex justify-start">
                  <div className="bg-white/20 rounded-lg p-3 max-w-xs">
                    <p className="text-white text-sm">Hello! I'm your AI companion. How can I help you learn today?</p>
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="bg-[#E85A7A] rounded-lg p-3 max-w-xs">
                    <p className="text-white text-sm">Can you explain quantum physics?</p>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Input
                  placeholder="Ask me anything..."
                  className="bg-white/10 border-white/30 text-white placeholder:text-white/60"
                />
                <Button className="bg-white text-[#6C5CE7] hover:bg-white/90">Send</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* 5. PYQ (Previous Year Questions) */}
      <section
        id="section-5"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#FF6B6B] to-[#EE5A52] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <BookOpen className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">Previous Year Questions</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Access comprehensive collections of previous year questions with detailed solutions and explanations.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {["Mathematics", "Physics", "Chemistry"].map((subject) => (
              <Card key={subject} className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">{subject}</CardTitle>
                  <CardDescription className="text-white/70">2020-2024 Papers</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-white text-[#FF6B6B] hover:bg-white/90">View Questions</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Library */}
      <section
        id="section-6"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#4ECDC4] to-[#44A08D] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <Library className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">Digital Library</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Access thousands of books, research papers, and educational resources in our comprehensive digital library.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {["Textbooks", "Research Papers", "Reference Materials", "E-Books"].map((category) => (
              <Card key={category} className="bg-white/10 backdrop-blur-sm border-white/20">
                <CardContent className="p-6 text-center">
                  <Library className="w-8 h-8 text-white mx-auto mb-3" />
                  <h3 className="text-white font-semibold mb-2">{category}</h3>
                  <p className="text-white/70 text-sm">1000+ Resources</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Performance */}
      <section
        id="section-7"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#A8E6CF] to-[#7FCDCD] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <TrendingUp className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">Performance Analytics</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Track your learning progress with detailed analytics and personalized insights to improve your performance.
          </p>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Study Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between text-white">
                    <span>Hours Studied</span>
                    <span className="font-bold">127h</span>
                  </div>
                  <div className="flex justify-between text-white">
                    <span>Topics Completed</span>
                    <span className="font-bold">45/60</span>
                  </div>
                  <div className="flex justify-between text-white">
                    <span>Average Score</span>
                    <span className="font-bold">87%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader>
                <CardTitle className="text-white">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-white text-sm">
                    <span className="font-semibold">Mathematics Quiz</span> - 92%
                  </div>
                  <div className="text-white text-sm">
                    <span className="font-semibold">Physics Notes</span> - Uploaded
                  </div>
                  <div className="text-white text-sm">
                    <span className="font-semibold">Chemistry Summary</span> - Generated
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* 8. Your Profile */}
      <section
        id="section-8"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#FFB6C1] to-[#FFA07A] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <User className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">Your Profile</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Manage your account, preferences, and learning journey all in one place.
          </p>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 max-w-md mx-auto">
            <CardContent className="p-8">
              <div className="w-24 h-24 bg-white/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                <User className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-white text-xl font-semibold mb-2">John Doe</h3>
              <p className="text-white/70 mb-4">Computer Science Student</p>
              <div className="space-y-2 text-left">
                <div className="flex justify-between text-white text-sm">
                  <span>Level:</span>
                  <span>Advanced</span>
                </div>
                <div className="flex justify-between text-white text-sm">
                  <span>Points:</span>
                  <span>2,847</span>
                </div>
                <div className="flex justify-between text-white text-sm">
                  <span>Streak:</span>
                  <span>15 days</span>
                </div>
              </div>
              <Button className="w-full mt-6 bg-white text-[#FFB6C1] hover:bg-white/90">Edit Profile</Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* 9. Contact Us */}
      <section
        id="section-9"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#667eea] to-[#764ba2] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <Mail className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">Contact Us</h2>
          <p className="text-white/90 text-xl mb-8 max-w-2xl mx-auto">
            Have questions or need support? We're here to help you succeed in your learning journey.
          </p>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 max-w-2xl mx-auto">
            <CardContent className="p-8">
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input
                    placeholder="Your Name"
                    className="bg-white/10 border-white/30 text-white placeholder:text-white/60"
                  />
                  <Input
                    placeholder="Your Email"
                    className="bg-white/10 border-white/30 text-white placeholder:text-white/60"
                  />
                </div>
                <Input
                  placeholder="Subject"
                  className="bg-white/10 border-white/30 text-white placeholder:text-white/60"
                />
                <Textarea
                  placeholder="Your Message"
                  className="min-h-32 bg-white/10 border-white/30 text-white placeholder:text-white/60"
                />
                <Button className="w-full bg-white text-[#667eea] hover:bg-white/90">Send Message</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* 10. Disclaimer */}
      <section
        id="section-10"
        className="scroll-section min-h-screen bg-gradient-to-br from-[#434343] to-[#000000] flex items-center justify-center p-8"
      >
        <div className="max-w-4xl mx-auto text-center">
          <FileText className="w-16 h-16 text-white mx-auto mb-6" />
          <h2 className="text-5xl font-bold text-white mb-6">Disclaimer</h2>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-8 text-left">
              <div className="space-y-4 text-white/90">
                <p>
                  <strong className="text-white">Educational Purpose:</strong> This platform is designed for educational
                  purposes only. All content and AI-generated materials should be used as supplementary learning tools.
                </p>
                <p>
                  <strong className="text-white">Accuracy:</strong> While we strive for accuracy, AI-generated content
                  may contain errors. Always verify important information with authoritative sources.
                </p>
                <p>
                  <strong className="text-white">Privacy:</strong> We respect your privacy and handle your data
                  according to our privacy policy. Your uploaded notes and personal information are secure.
                </p>
                <p>
                  <strong className="text-white">Usage Rights:</strong> Users retain ownership of their uploaded
                  content. Our AI processing is used solely to enhance your learning experience.
                </p>
                <p className="text-center text-white/70 text-sm mt-8">
                  © 2024 Cyclemon. All rights reserved. | Version 1.0
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
